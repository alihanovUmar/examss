import React from "react";

export const Hero = () => {
  return (
    <section className="hero">
      <div className="container">
        <h1>Tagline: Your Gateway to Stylish Finds</h1>
      </div>
    </section>
  );
};
