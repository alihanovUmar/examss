import "./App.css";
import { Header } from "./components/Header/Header";
import { Hero } from "./pages/Home/Hero/Hero";
import { Search } from "./pages/Home/Search/Search";
import Slider from "./pages/Home/Slider/Slider";

function App() {
  return (
    <div className="App">
      <Header />
      <Hero />
      <Slider />
      <Search />
    </div>
  );
}

export default App;
