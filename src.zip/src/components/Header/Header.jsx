import React from "react";
import { CiHome } from "react-icons/ci";
import { SlBasket } from "react-icons/sl";
import { MdFavoriteBorder } from "react-icons/md";
import { Link } from "react-router-dom";

export const Header = () => {
  return (
    <header>
      <div className="container">
        <div className="header__left__right">
          <div className="header__left">
            <button className="header__btn">
              <CiHome className="header__btn__icon" />
              Shop4Goodies
            </button>
          </div>
          <div className="header__right">
            <nav>
              <ul>
                <li className="header__link">
                  <Link to="/">About</Link>
                </li>
                <li className="header__link">
                  <Link to="">Shop </Link>
                </li>
                <li className="header__link">
                  <Link to="">Help</Link>
                </li>
                <li className="header__link">
                  <Link to="">Profile</Link>
                </li>
              </ul>
            </nav>
            <button className="header__basket">
              <MdFavoriteBorder /> Favorites
            </button>
            <button className="header__basket">
              <SlBasket className="header__btn__icon" /> Your cart
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
